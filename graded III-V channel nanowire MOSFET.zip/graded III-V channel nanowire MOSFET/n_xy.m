function [] = n_xy()

global k

load shie.mat
load uni_const.mat
load dev_param.mat
load cal_val.mat
load nxy.mat 

% cs=sqrt(2*me_s/hcut^2);%constant
cs1=sqrt(2*me_s1/hcut^2);%constant
% cox=sqrt(2*me_ox/hcut^2);%%%wave function penetration effect nullified for convergence
cox=cs1;
cs=cs1;
cox1=sqrt(2*me_ox1/hcut^2);

eigen=eigene/qe;
n1=zeros(size(xx(:)'));

for i=1:length(eigen)
    Egrid=(eigen(i)+int_interval*1e-2):int_interval:(eigen(i)+eg_lim);
    DOS=(1./sqrt(Egrid*qe-eigen(i)*qe));
    f=1./(1+exp((Egrid-Ef)/(K*T/qe)));
    N=trapz(Egrid*qe,f.*DOS);
    temp=(shi_sq_rawe(i,:).*N);
    n1=n1+temp;
end


temp0=1*(xx<=-oxide_thicki | xx>(fin_width+oxide_thicki) | yy<=-oxide_thicki | yy>(fin_height+oxide_thicki));
temp1=1*(xx<=0 | xx>=fin_width | yy<=0 | yy>=fin_height);
temp2=1*((xx>fin_grade & xx<fin_width-fin_grade) & (yy>fin_grade & yy<fin_height-fin_grade));
temp3=temp0*cox1 +(temp1-temp0)*cox+ (~temp1-temp2)*cs1+ temp2*cs;
temp3=temp3(:)';
nxy(k,:)=n1.*temp3;

max(nxy(k,:))
save nxy.mat nxy 
end