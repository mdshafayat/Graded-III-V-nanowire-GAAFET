function [] = load_device_parameter()
%%% all units are S.I.
%%% with the changing geometry and condition change this file

load uni_const.mat

%%basic
T=300;%kelvin
oic=3e16;%oxide interface charge
use_dit=0;%0/1 no/yes

%% decide
refine_mesh=1;%1 for finwidth 30nm. increase accordingly
strain_=1;%1/0 y/n
mygrid_del=0.1e-9;
tolerance=2e-2;%best 1e-2
eigen_no=15;%best 50
pc_loc=1; % 0/1, home/buet
max_it=1000; %best 1000
CV_typ=1;%1/0 qunatum/semiclassical
update=.04;%best .04
Vg=-1.5:.1:1;
  %Vg=[-1.5 1];
%% geometry
fin_width=10e-9;
fin_height=10e-9;
fin_grade=2e-9;
fin_core=fin_width-2*fin_grade;
oxide_thick=1.5e-9;%symmetric %%%%%use 10n 8n 6n 4n 2n 1.5n
oxide_thicko=1e-9;%outer
oxide_thicki=5e-10;%inner
metal_thick=3e-9;%symmetric
channel_len=50e-9;

%% material
%metal Ti
% phi_m=4.6;%metal work func in eV
phi_m=3.55;%Hf=3.65 Ti=5.65 gate http://photonicswiki.org/index.php?title=Work_Function_of_Metals
m_metal=9.1e-31;%effective mass in metal
eps_m=1*eps0;

%insulator HfO2
kai_ox1=1.75;%oxide affinity in eV
Eg_ox1=5.8;%6.705 in eV [ref:DOI:10.1063/1.2218826]
eps_ox1=25*eps0;%10%3.9 atlas[ref: DOI:10.1021/cr900056b: eps=7][DOI: 10.1134/S0021364007030071; eps=10]
me_ox1=.08*m0;%Dos effective mass[ref:DOI:10.1063/1.2218826 ;me_ox=.3*m0][DOI: 10.1134/S0021364007030071;me_ox=.4*m0]
mhh_ox1=.5*m0;%[Doi:10.1063/1.1897431; 10.1063/1.2010607; mh=.7] [10.1109/NVMT.2008.4731201 ; mh=.46]
mlh_ox1=.16*m0;%[not sure]
me_ox_c1=m0;%conductivity effective mass [not sure]
mh_ox_c1=1.86*m0;%[DOI: 10.1134/S0021364007030071; (6.3+.36)^(1/3)][not sure]

%insulator Al2O3
kai_ox=1;%oxide affinity in eV
Eg_ox=9;%6.705 in eV [ref:DOI:10.1063/1.2218826]
eps_ox=9*eps0;%10%3.9 atlas[ref: DOI:10.1021/cr900056b: eps=7][DOI: 10.1134/S0021364007030071; eps=10]
me_ox=.4*m0;%Dos effective mass[ref:DOI:10.1063/1.2218826 ;me_ox=.3*m0][DOI: 10.1134/S0021364007030071;me_ox=.4*m0]
mhh_ox=.7*m0;%[Doi:10.1063/1.1897431; 10.1063/1.2010607; mh=.7] [10.1109/NVMT.2008.4731201 ; mh=.46]
mlh_ox=.46*m0;%[not sure]
me_ox_c=m0;%conductivity effective mass [not sure]
mh_ox_c=1.86*m0;%[DOI: 10.1134/S0021364007030071; (6.3+.36)^(1/3)][not sure]


%% nanowire Graded strained


if (strain_==0)
 %% core INGAAS; In=.53 
    kai_s=4.51;%semiconductor affinity in eV
    Eg_s=0.75;%in eV
    eps_s=13.899*eps0;

    me_s=.041*m0;%Dos effective mass [ref: ioffe.org]
    mhh_s=.457*m0;
    mlh_s=.052*m0;
    me_s_c=.041*m0;%conductivity effective mass [not sure]
    mhh_s_c=m0;%[not sure]
    mlh_s_c=m0;%[not sure]

    ni=6.3e17;%[ref: ioffe.org]
    Nc=2.1e23;
    Nv=7.7e24;
%%
else
  %% core INGAAS; In=.53 sub
    kai_s=4.4189;%semiconductor affinity in eV
    Eg_s=0.736;%in eV
    eps_s=14.0972*eps0;

    me_s=.0378*m0;%Dos effective mass [ref: ioffe.org]
    mhh_s=.3408*m0;
    mlh_s=.0403*m0;
    mso_s=.072*m0;
    
    me_s_c=.041*m0;%conductivity effective mass [not sure]
    mhh_s_c=m0;%[not sure]
    mlh_s_c=m0;%[not sure]

    ni=6.596e17;%[ref: ioffe.org]
    Nc=1.841e23;
    Nv=5.186e24;
    
  %% outer INGAAS; In=.75 ch 
    kai_s1=4.486;%semiconductor affinity in eV
    Eg_s1=0.5677;%in eV
    eps_s1=14.59*eps0;

    me_s1=.0317*m0;%Dos effective mass [ref: ioffe.org]
    mhh_s1=.3373*m0;
    mlh_s1=.049*m0;
    mso_s1=.0372*m0;
    
    me_s_c1=.041*m0;%conductivity effective mass [not sure]
    mhh_s_c1=m0;%[not sure]
    mlh_s_c1=m0;%[not sure]

    ni1=1.488e19;%[ref: ioffe.org]
    Nc1=1.4136e23;
    Nv1=5.18e24;    
    
end

%% doping fully deplated
dop_typ=1;%1/-1 p-type/n-type
dop1=2e22;
dop=2e22;

%% Carrier density calculation accuracy
int_interval=1e-4;%1e-5
eg_lim=10*K*T/qe;%100kT
po_ints=2000;%5000

%% my int is not fully generalized {edit manually}

%%
save dev_param.mat
end

