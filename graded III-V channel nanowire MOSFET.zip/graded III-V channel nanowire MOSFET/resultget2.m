clc;
clear all;
close all;

load nxy.mat
load phhxy.mat
load plhxy.mat
load uni_const.mat
load dev_param.mat
load cal_val.mat

global Vapp k

Q=zeros(1,length(Vg));
Ee1=zeros(1,length(Vg));
Eh1=zeros(1,length(Vg));
El1=zeros(1,length(Vg));
Vox_c=zeros(1,length(Vg));
Vox_m=zeros(1,length(Vg));
phi_sc=zeros(1,length(Vg));
phi_sm=zeros(1,length(Vg));
save cal.mat Q Ee1 Eh1 El1 Vox_c Vox_m phi_sc phi_sm

for k=1:length(Vg)
Vapp=Vg(k)

load cal.mat Q Ee1 Eh1 El1 Vox_c Vox_m phi_sc phi_sm
Q(k)=pois();

schroe();
schrohh();
schrolh();

load shie.mat
load shihh.mat
load shilh.mat
Ee1(k)=eigene(1);
Eh1(k)=eigenhh(1);
El1(k)=eigenlh(1);

load pois.mat
vv=reshape(V,size(xx));
v1=vv(floor(oxide_thick/mygrid_del)+1,floor(oxide_thick/mygrid_del)+1);%ch corner
v2=vv(round(end/2),floor(oxide_thick/mygrid_del)+1);%mid point of ch side line
v3=vv(1,1);%%oxide corner
v4=vv(round(end/2),round(end/2));%ch mid
Vox_c(k)=abs(v3-v1);%c-corner, m-middle
Vox_m(k)=abs(v3-v2);
phi_sc(k)=abs(v1-v4);
phi_sm(k)=abs(v2-v1);


save cal.mat Q Ee1 Eh1 El1 Vox_c Vox_m phi_sc phi_sm
% save QQ.mat Q
end


%% CV_quan
%%%CV
load cal.mat
% load QQ.mat
C_prime=diff(Q)./diff(Vg);
Vgs=Vg(1:end-1);% leaving the last element ......forward difference estimate
% figure(1),plot(Vgs,abs(C_prime));

figure(18),
a = 1;
b = [1/2 1/2]; %%moving average filter
y = filter(b,a,abs(C_prime));
plot(Vgs(2:end),y(2:end));%%%curve sifts  a little right but its okay as during diff the curve sifted to left once

%% QV
figure(19),
plot(Vgs,abs(Q(1:end-1)));

%% 1st Eigen with Vg
figure(20),
plot(Vg,Ee1/1.6e-19,Vg,Eh1/1.6e-19,Vg,El1/1.6e-19);
%% Vox with Vg
figure(21),
plot(Vg,Vox_c,Vg,Vox_m);
%% phi_s with Vg
figure(22),
plot(Vg,phi_sc,Vg,phi_sm);

voxdrop=Vox_m;
save voxdrop.mat voxdrop