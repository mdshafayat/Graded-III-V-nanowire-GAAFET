function [ Eng] = energy_e(x,y)

load gridmy.mat xx yy 
load pois.mat V
load uni_const.mat
load dev_param.mat
load cal_val.mat


%% forming Ec
V=reshape(V,size(xx));
temp0=1*(xx<=-oxide_thicki | xx>(fin_width+oxide_thicki) | yy<=-oxide_thicki | yy>(fin_height+oxide_thicki));
temp1=1*(xx<=0 | xx>=fin_width | yy<=0 | yy>=fin_height);
temp2=1*((xx>fin_grade & xx<fin_width-fin_grade) & (yy>fin_grade & yy<fin_height-fin_grade));
Eceq=temp0*Eg_ox1/2 +(temp1-temp0)*Eg_ox/2 + (~temp1-temp2)*phi_fc1+ temp2*phi_fc;
Ec=(Eceq-V)*qe;
Ecmin=min(min(Ec));
Ec=Ec-Ecmin;

% figure(5),
% surf(xx,yy,Eceq,'FaceColor','interp',... 	
%     'EdgeColor','none',...
%   	'FaceLighting','phong');

Eng=interp2(xx,yy,Ec,x,y,'nearest');

%%
save Ecm.mat Ecmin Ec
end

